#include "game.hpp"
#include <cstdlib>

Game::Game():
  tetromino_(static_cast<Tetromino::Name>(rand() % 7)), base {}



void Game::KeyPressed(int btnCode)
{
  Tetromino t = tetromino_;
  switch (d)
  {
  case 119: t.rotate(Tetromino::LEFT);
    break;
  case 115: t.move(0, 1);
    break;
  case 97: t.move(-1, 0);
    break;
  case 100: t.move(1, 0);
    break;
  }
  if (!well_.isCollision(t))
    tetromino_ = t;
}

void Game::UpdateF(float deltaTime)
{
    tick();
    draw();
}

void Game::draw()
{
  well_.draw();
  tetromino_.draw();
}

void Game::tick()
{
  Tetromino t = tetromino_;
  t.move(0, 1);
  if (!well_.isCollision(t))
    tetromino_ = t;
  else
  {
    well_.unite(tetromino_);
    well_.removeSolidLines();
    tetromino_ = Tetromino
      (static_cast<Tetromino::Name>(rand() % 7));
    if (well_.isCollision(tetromino_))
      restart();
  }
}

void Game::restart()
{
  well_ = Well();
}


