#pragma once
#include "tetromino.hpp"
#include "well.hpp"

class Painter;

class Game: public BaseApp
{
public:
    Game(int xSize=100, int ySize=80);
    virtual void KeyPressed(int btnCode);
    virtual void UpdateF(float deltaTime);
private:
    void restart();

    void draw();
    void tick();

  Well well_;
  Tetromino tetromino_;
};
