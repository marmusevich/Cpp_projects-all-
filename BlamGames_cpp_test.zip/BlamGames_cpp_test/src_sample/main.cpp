#include "TestApp.h"

int main ()
{
	TestApp app;
	app.Run();
}
