#include "game.hpp"
#include <cstdlib>
#include <conio.h>

#include <sstream>


Game::Game():
    BaseApp(WELL_X_SIZE + 2 + 2 + 4, WELL_Y_SIZE + 2 + 1),
    well(),
    tet_Current((WELL_X_SIZE-4)/2),
    tet_Next(),
    linesDestroy(0) {}


void Game::KeyPressed(int btnCode)
{
    if (btnCode == 27) //esc
        abort(); //выход из игры
    if (btnCode == 119) //w
        keyProcess(UP);
    else if (btnCode == 115) //s
        keyProcess(DOWN);
    else if (btnCode == 97) //a
        keyProcess(LEFT);
    else if (btnCode == 100) //d
        keyProcess(RIGHT);

    else if (btnCode == 224) //клавиши
    {
        int arwCode = getch();
        if (arwCode == 72)
            keyProcess(UP);
        else if (arwCode == 80)
            keyProcess(DOWN);
        else if (arwCode == 75)
            keyProcess(LEFT);
        else if (arwCode == 77)
            keyProcess(RIGHT);
    }

}

void Game::UpdateF(float deltaTime)
{
    draw();

    //tick
    static float _Time=0.0;
    _Time+=deltaTime;
    if(_Time < GAME_SPEED)
        return;
    _Time=0;
    tick();
}



void Game::restart()
{
    well = Well();
    tet_Current = Tetromino ();
    tet_Next = Tetromino ();
    linesDestroy = 0;
}



void Game::draw()
{
    //позиция следущей фигуры фигуры
    int next_x_pos = WELL_X_SIZE + 2 ;
    int next_y_pos = 0;
    int next_syze = 4;

    //рисуем рамки
    // вокруг колодца
    for(int x = 0; x < WELL_X_SIZE; ++x)
    {
        drawChar(x + 1, 0, '-');
        drawChar(x + 1, WELL_Y_SIZE + 1, '-');
    }
    for(int y = 0; y < WELL_Y_SIZE; ++y)
    {
        drawChar(0, y + 1, '|');
        drawChar(WELL_X_SIZE + 1, y + 1, '|');
    }
    drawChar(0, 0, '+');
    drawChar(0, WELL_Y_SIZE + 1, '+');
    drawChar(WELL_X_SIZE + 1, 0, '+');
    drawChar(WELL_X_SIZE + 1, WELL_Y_SIZE + 1, '+');
    // вокруг следущей фигуры
    for(int i = 0; i < next_syze; ++i)
    {
        drawChar(next_x_pos + i + 1, next_y_pos, '-');
        drawChar(next_x_pos + i + 1, next_y_pos + next_syze + 1, '-');
        drawChar(next_x_pos, next_y_pos + i + 1 , '|');
        drawChar(next_x_pos + next_syze + 1, next_y_pos + i + 1, '|');
    }
    drawChar(next_x_pos, next_y_pos, '+');
    drawChar(next_x_pos, next_y_pos + next_syze + 1, '+');
    drawChar(next_x_pos + next_syze + 1, next_y_pos, '+');
    drawChar(next_x_pos + next_syze + 1, next_y_pos + next_syze + 1, '+');


    // игровые объекты
    well.draw(this, 1, 1);
    tet_Current.draw(this, 1, 1);
    drawFullRectangle(next_x_pos + 1, next_y_pos + 1, next_syze, next_syze, ' ');
    tet_Next.draw(this, next_x_pos + 1, next_y_pos + 1);

    // количество убраных линий
    ostringstream sout("");
    sout <<"Lines removed: " <<linesDestroy <<"";

    drawString(0, WELL_Y_SIZE + 2, sout.str());
}


void Game::tick()
{
    Tetromino t = tet_Current;
    t.move(0, 1);
    if (!well.isCollision(t))
        tet_Current = t;
    else
    {
        well.unite(tet_Current);
        linesDestroy += well.removeSolidLines();
        tet_Current = tet_Next;
        tet_Current.moveTo((WELL_X_SIZE-4)/2, 0);
        tet_Next = Tetromino ();
        if (well.isCollision(tet_Current))
            restart();
    }
}


void Game::keyProcess(Direction direction)
{
    Tetromino t = tet_Current;
    switch (direction)
    {
    case UP:
        t.rotate(Tetromino::LEFT);
        break;
    case DOWN:
        t.move(0, 1);
        break;
    case LEFT:
        t.move(-1, 0);
        break;
    case RIGHT:
        t.move(1, 0);
        break;
    }
    if (!well.isCollision(t))
        tet_Current = t;
}

void Game::drawFullRectangle(int x, int y, int w, int h, wchar_t c)
{
    for (int yy = y; yy < (y + h); ++yy)
        for (int xx = x; xx < (x + w); ++xx)
            drawChar(xx, yy, c);
}

void Game::drawString(int x, int y, string str)
{
    int len = str.length();
    for(int i = 0; i<len; ++i)
        drawChar(x+i, y, static_cast<wchar_t> (str[i]));
}

void Game::drawChar(int x, int y, wchar_t c)
{
    if(x>=X_SIZE || x<0)
        return;
    if(y>=Y_SIZE || y<0)
        return;
    SetChar(x, y, c);
}
