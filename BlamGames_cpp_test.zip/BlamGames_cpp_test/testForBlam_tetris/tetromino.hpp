#pragma once


class Game;

/// фигуры тетриса
class Tetromino
{
public:
    /// направления движения
    enum Direction { LEFT = -1, RIGHT = 1 };
    /// типы фигур
    enum Name { I, J, L, O, S, Z, T };
    /// создание тетромины по имени и в позиции
    Tetromino(Name, int x = 0, int y = 0);

    /// создание случайной тетромины и в позиции
    Tetromino(int x = 0, int y = 0);

    /// рисование тетромины
    void draw(Game *gm, int offset_x = 0, int offset_y = 0) const;
    /// перемещение тетромины на dx, dy
    void move(int dx, int dy);
    /// переместить в позицию
    void moveTo(int x, int y);

    /// поворот тетромины
    void rotate(Direction);
    /// проверить заполнение фигуры в относительных координатах
    bool map(int x, int y) const;
    /// вернуть координаты фигуры
    int x() const    { return pos_x; }
    int y() const    { return pos_y; }
private:
    Name name_;
    int angel_;
    int pos_x;
    int pos_y;
};
