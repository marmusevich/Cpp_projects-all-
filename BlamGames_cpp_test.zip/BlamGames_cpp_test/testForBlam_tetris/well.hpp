#pragma once

#include "BaseApp.h"

class Game;
class Tetromino;

///размеры колодца по горизонтали и вертикали в символах
const int WELL_X_SIZE = 15;
const int WELL_Y_SIZE = 20;


/// колодец
class Well
{

public:

    /// конструктор
    Well();

    /// рисует колодец
    void draw(Game *gm, int offset_x = 0, int offset_y = 0) const;
    /// проверка на столкновения тетромины с блоками в колодце
    bool isCollision(const Tetromino &) const;
    /// перенос тетромины в колодец
    void unite(const Tetromino &);
    /// удаление полностью заполненых строки
    int removeSolidLines();

private:

    bool map_[WELL_Y_SIZE][WELL_X_SIZE];
};
