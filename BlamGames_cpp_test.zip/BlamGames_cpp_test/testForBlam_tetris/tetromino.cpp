#include "tetromino.hpp"
#include "game.hpp"

#include <time.h>


Tetromino::Tetromino(Name name, int x, int y):
    name_(name),
    angel_(0),
    pos_x(x),
    pos_y(y)
    {srand(time(NULL));}

Tetromino::Tetromino(int x, int y):
    name_(static_cast<Tetromino::Name>(rand() % 7)),
    angel_(0),
    pos_x(x),
    pos_y(y)
    {srand(time(NULL));}


void Tetromino::draw(Game *gm, int offset_x, int offset_y) const
{
    for (int yy = 0; yy < 4; ++yy)
        for (int xx = 0; xx < 4; ++xx)
            if (map(xx, yy))
                gm->drawChar(xx + pos_x + offset_x, yy + pos_y + offset_y, L'O');
}

bool Tetromino::map(int x, int y) const
{
    static const char *SHAPES[] =
    {
        "  8 " // I
        "  8 "
        "  8 "
        "  8 ",

        "  8 " // J
        "  8 "
        " 88 "
        "    ",

        " 8  " // L
        " 8  "
        " 88 "
        "    ",

        " 88 " // O
        " 88 "
        "    "
        "    ",

        "  8 " // S
        " 88 "
        " 8  "
        "    ",

        "  8 " // Z
        " 88 "
        " 8  "
        "    ",

        "    " // T
        " 888"
        "  8 "
        "    "
    };

    //учет поворота
    int xt=0, yt=0;
    switch (angel_)
    {
    case 0:
        xt = x;
        yt = y;
        break;
    case 1:
        xt = y;
        yt = 4 - x - 1;
        break;
    case 2:
        xt = 4 - x - 1;
        yt = 4 - y - 1;
        break;
    case 3:
        xt = 4 - y - 1 ;
        yt = x;
        break;
    }
    return SHAPES[name_][yt * 4 + xt] != ' ';
}

void Tetromino::move(int dx, int dy)
{
    pos_x += dx;
    pos_y += dy;
}

void Tetromino::moveTo(int x, int y)
{
    pos_x = x;
    pos_y = y;
}


void Tetromino::rotate(Direction d)
{
    angel_ = (angel_ + d + 4) % 4;
    cout << "                                   " <<angel_ <<endl;

}
