#include "game.hpp"
int main()
{
    Game app;
    app.Run();
    return 0;
}
