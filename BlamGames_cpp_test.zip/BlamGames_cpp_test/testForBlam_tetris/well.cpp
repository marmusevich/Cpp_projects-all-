#include "well.hpp"
#include "tetromino.hpp"

#include "game.hpp"


Well::Well()
{
    for (int yy = 0; yy < WELL_Y_SIZE; ++yy)
        for (int xx = 0; xx < WELL_X_SIZE; ++xx)
            map_[yy][xx] = false;
}

void Well::draw(Game *gm, int offset_x, int offset_y) const
{
    for (int y = 0; y < WELL_Y_SIZE; ++y)
        for (int x = 0; x < WELL_X_SIZE; ++x)
            if (map_[y][x])
                gm->drawChar(x + offset_x, y + offset_y, L'X');
            else
                gm->drawChar(x + offset_x, y + offset_y, L'.');
}

bool Well::isCollision(const Tetromino &t) const
{
    for (int y = 0; y < 4; ++y)
        for (int x = 0; x < 4; ++x)
            if (t.map(x, y))
            {
                int wx = x + t.x();
                int wy = y + t.y();
                if (wx < 0 ||
                        wx >= WELL_X_SIZE ||
                        wy < 0 ||
                        wy >= WELL_Y_SIZE)
                    return true;
                if (map_[wy][wx])
                    return true;
            }
    return false;
}

void Well::unite(const Tetromino &t)
{
    for (int y = 0; y < 4; ++y)
        for (int x = 0; x < 4; ++x)
        {
            int wx = x + t.x();
            int wy = y + t.y();
            if (wx >= 0 &&
                    wx < WELL_X_SIZE &&
                    wy >= 0 &&
                    wy < WELL_Y_SIZE)
                map_[wy][wx] = map_[wy][wx] || t.map(x, y);
        }
}

int Well::removeSolidLines()
{
    int res = 0;
    for (int y = 0; y < WELL_Y_SIZE; ++y)
    {
        bool solid = true;
        for (int x = 0; x < WELL_X_SIZE; ++x)
            if (!map_[y][x])
            {
                solid = false;
                break;
            }
        if (solid)
        {
            ++res;
            for (int yy = y - 1; yy >= 0; --yy)
                for (int x = 0; x < WELL_X_SIZE; ++x)
                    map_[yy + 1][x] = map_[yy][x];
        }
        for (int x = 0; x < WELL_X_SIZE; ++x)
            map_[0][x] = false;
    }
    return res;
}
