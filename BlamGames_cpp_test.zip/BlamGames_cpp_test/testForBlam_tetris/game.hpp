#pragma once

#include "tetromino.hpp"
#include "well.hpp"
#include "BaseApp.h"

///размеры колодца по горизонтали и вертикали в символах
const float GAME_SPEED = 0.5;

///размеры колодца по горизонтали и вертикали в символах
extern const int WELL_X_SIZE;
extern const int WELL_Y_SIZE;

/// класс игры.
class Game: public BaseApp
{
public:
    ///направления перемещения
    enum Direction { UP, DOWN, LEFT, RIGHT};
    ///конструктор
    Game();
    /// перезапуск
    void restart();
    /// обработчик событий клавиатуры
    virtual void KeyPressed(int btnCode);
    /// обработчик событий главного цикла
    virtual void UpdateF(float deltaTime);
    /// нарисовать заполненый прямоугольник
    void drawFullRectangle(int x, int y, int w, int h, wchar_t c=' ');
    /// нарисовать строку
    void drawString(int x, int y, string str);
    ///рисуем символ с проверкой границ
    void drawChar(int x, int y, wchar_t c);
private:
    ///рисование
    void draw();
    ///расчеты
    void tick();
    ///
    void keyProcess(Direction);

    Well well;
    Tetromino tet_Current;
    Tetromino tet_Next;

    int linesDestroy;

    //запрет копирования и присваивания
    Game(const Game& other);
    Game& operator=(const Game& other);

};
